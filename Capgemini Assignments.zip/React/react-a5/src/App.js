import "./App.css";
import React from "react";
import DigitalClock from "./component/DigitalClock";

function App() {
  return (
    <div className="App">
      <DigitalClock />
    </div>
  );
}

export default App;
