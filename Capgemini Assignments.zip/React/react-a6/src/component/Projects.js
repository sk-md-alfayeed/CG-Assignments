import React from "react";

function Projects() {
  return (
    <div>
      <h1>You Clicked Projects</h1>
    </div>
  );
}

export default Projects;
