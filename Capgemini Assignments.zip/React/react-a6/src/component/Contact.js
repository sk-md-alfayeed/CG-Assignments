import React from "react";

function Contact() {
  return (
    <div>
      <h1>You Clicked Contact</h1>
    </div>
  );
}

export default Contact;
