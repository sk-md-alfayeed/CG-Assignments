import "./App.css";
import React from "react";

import Calculator from "./component/Calculator";

function App() {
  return (
    <div className="App">
      <Calculator />
    </div>
  );
}

export default App;
