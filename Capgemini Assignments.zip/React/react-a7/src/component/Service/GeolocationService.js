import React, { useEffect, useState } from "react";

function GeolocationService() {
  const key = d433538c6ec5d7becb084b24a37866a7;
  let lat = 0.0;
  let lon = 0.0;
  const [weather, setWeather] = useState("");
}

export default GeolocationService;
