
import './App.css';
import React from 'react'

import EmployeeList from './component/EmployeeList';

function App() {
  return (
    <div className="App">
     <EmployeeList/> 
      
    </div>
  );
}

export default App;
